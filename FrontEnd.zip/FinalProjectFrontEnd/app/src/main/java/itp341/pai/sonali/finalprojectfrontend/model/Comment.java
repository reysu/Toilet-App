package itp341.pai.sonali.finalprojectfrontend.model;

import java.util.Date;

/**
 * Created by Sonali Pai on 11/10/2017.
 */

public class Comment {

    //data members
    int commentId;
    String title;
    String commentText;
    Date commentDate;
    User user;
}
