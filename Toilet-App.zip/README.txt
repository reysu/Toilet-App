Toilet App
==========
Sonali Pai, Eric Su, Caleb Thomas, Ethan Xiong, Brian Lee


#What works
 
All functionality for the front end works. All the functionality for the back end works. Google Maps API works to show our current location. 


#What doesn't

We need to connect the front end to the server to display toilet information, display toilet list, upload photos, display photos, display search, display maps of all toilets, display comments, submit commments. 